sqlplus system/manager << EOF
set echo on
@tdcts.sql 
@hr_main.sql hr demo temp change_on_install

