REM script name: bz_tr_priv.sql
REM Grants execute on dbms_tranform to bz
REM Grant select on hr.employees to bz and bz_adm
REM 
REM 
REM
REM version: 9.0.1
define hr_pass = &1

grant execute on dbms_transform to bz;

connect hr/&hr_pass
grant select on hr.employees to bz;
grant select on hr.employees to bz_adm;

	
