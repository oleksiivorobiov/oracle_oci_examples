REM script name: bz_tr_main.sql
REM Creates a transformation to verify order and fill-in missing fields
REM of bzcardorder
REM 
REM 
REM
REM version: 9.0.1
REM change:  initial version
REM
REM =======================================================
REM cleanup section
REM =======================================================

SET VERIFY OFF

define bz_adm_pass  = &1
define master_pass  = &2
define hr_pass      = &3

spool bz_tr
CONNECT system/&master_pass as sysdba;
@@bz_tr_priv.sql &hr_pass
CONNECT bz_adm/&bz_adm_pass
@@bz_tr_mapping.sql

spool off
