declare
	oorder BZCARDORDER_TYP;
	norder BZCARDORDER_typ;
begin
	oorder := BzCardOrder_typ(101, null, null);
	dbms_Transform.compute_transformation(message => oorder, 
		transformation_schema => 'BZ_ADM', 
		transformation_name => 'BZCARDVERIFY', 
		transformed_message => norder);
end;
/
