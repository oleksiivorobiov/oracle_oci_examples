sqlplus system/manager << EOF
set echo on
@bz_tr_main.sql bz_adm master hr
