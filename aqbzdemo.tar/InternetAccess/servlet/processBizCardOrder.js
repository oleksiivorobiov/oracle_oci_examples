function processUserInput() {
  var aqxmldoc = '';

  // Generate IDAP Envelope
  aqxmldoc += '<?xml version="1.0"?>\n';
  aqxmldoc += '<Envelope xmlns="http://ns.oracle.com/AQ/schemas/envelope">\n';
  aqxmldoc += '<Body>\n';


  //Find the order type
  //a. New Business Card Order -- This would generate an enqueue statement
  //b. Search Business Card Order--This would generate dequeue with browse mode
  //c. Remove Business Card Order--This would generate dequeue with remove mode

  error = false;
  if (document.request.elements['requestType'].selectedIndex == 0) {
    // generate enqueue statement
    aqxmldoc += generateEnqueue();
  } else {
    // generate a dequeue statement
    aqxmldoc += generateDequeue();
  }
  if (error)
    return;
  aqxmldoc += '</Body>\n';
  aqxmldoc += '</Envelope>';
  document.aqxmlform.aqxmldoc.value = aqxmldoc;
  return;  // End of processUserInput function


  function xmlOrder () {
    aqxmldoc = '';
    aqxmldoc += '        <BZCARDORDER_TYP>\n';
    if ( (employee_id = document.request.elements['employeeId'].value) != 0)
      aqxmldoc += '          <EMPLOYEE_ID>'+employee_id + '</EMPLOYEE_ID>\n';
    else {
      firstName = document.request.elements['firstName'].value;
      lastName = document.request.elements['lastName'].value;
      if ( (firstName != null && firstName != "") || 
	   (lastName != null && lastName != ""))
	{
	  aqxmldoc += '          <FIRST_NAME> '+ firstName + 
	    ' </FIRST_NAME>\n';
	  aqxmldoc += '          <LAST_NAME> '+ lastName + 
	    ' </LAST_NAME>\n';	  
	}
      else {
	error = true;
	return '';
      }
    }
    aqxmldoc += '        </BZCARDORDER_TYP>\n';
    return aqxmldoc;
  }

  function generateEnqueue () {
    aqxmldoc = '';
    // generate an enqueue statement
    aqxmldoc += '<AQXmlSend xmlns = "http://ns.oracle.com/AQ/schemas/access">\n';
    aqxmldoc += '  <producer_options>\n';
    aqxmldoc += '     <destination>BZ_ADM.bzcardorders_q</destination>\n';
    aqxmldoc += '  </producer_options>\n';
    aqxmldoc += '  <message_set>\n';
    aqxmldoc += '    <message_count>1</message_count>\n';
    aqxmldoc += '    <message>\n';
    aqxmldoc += '      <message_number>1</message_number>\n';
    aqxmldoc += '      <message_header>\n';
    aqxmldoc += '        <correlation>1</correlation>\n';
    aqxmldoc += '        <sender_id>\n';
    aqxmldoc += '          <agent_name>'+ 'bob' + '</agent_name>\n';
    aqxmldoc += '        </sender_id>\n';
    aqxmldoc += '      </message_header>\n';
    aqxmldoc += '      <message_payload>\n';
    
    error = false;
    aqxmldoc += xmlOrder();
    if (error) {
      alert ('Must enter Employee Id or Employee Name');
      return;
    }
    
    aqxmldoc += '      </message_payload>\n';
    aqxmldoc += '    </message>\n';
    aqxmldoc += '  </message_set>\n';
    aqxmldoc += '  <AQXmlCommit>\n';
    aqxmldoc += '  </AQXmlCommit>\n';
    aqxmldoc += '</AQXmlSend>\n';   
    return aqxmldoc;
  }

  function generateDequeue() {
    aqxmldoc = '';
    
    aqxmldoc += '        <AQXmlReceive xmlns = "http://ns.oracle.com/AQ/schemas/access">\n';
    aqxmldoc += '          <consumer_options>\n';
    aqxmldoc += '            <destination>BZ_ADM.bzcardorders_q</destination>\n';
    aqxmldoc += '            <consumer_name>SHIPPING</consumer_name>\n';

    aqxmldoc += '            <selector>\n';
    orderno   = document.request.elements['orderNo'].value;
    if (orderno != null && orderno != '') {
      aqxmldoc += '              <message_id>' + orderno + '</message_id>\n';
    } else {
      aqxmldoc += '              <condition> ';
      firstName = document.request.elements['firstName'].value;
      lastName  = document.request.elements['lastName'].value;
      employeeId = document.request.elements['employeeId'].value;
      if (employeeId != null && employeeId != '')
	aqxmldoc += 'tab.user_data.employee_id= ' + employeeId;
      else if ( (firstName != null && firstName != '') ||
		(lastName != null && lastName != '')) {
	if (isFirst = (firstName != null && firstName != ''))
	  aqxmldoc += 'tab.user_data.first_Name=' + "'" + firstName + "'";
	if (lastName != null && lastName != '') {
	  aqxmldoc += isFirst ? ' AND ': '';
	  aqxmldoc += 'tab.user_data.last_Name=' + "'" + lastName + "'";
	} 
      }else {
	error = true;
	alert ('Must Enter one of EmployeeId or Order # or Name');
	return '';
      }
      aqxmldoc += '</condition>\n';
    }
    aqxmldoc += '            </selector>\n';
    if (document.request.elements['requestType'].selectedIndex == 1)
      aqxmldoc += '            <dequeue_mode>BROWSE</dequeue_mode>\n';
    else
      aqxmldoc += '            <dequeue_mode>REMOVE</dequeue_mode>\n';
    aqxmldoc += '          </consumer_options>\n';
    aqxmldoc += '          <AQXmlCommit>\n';
    aqxmldoc += '          </AQXmlCommit>\n';
    aqxmldoc += '        </AQXmlReceive>\n';
    return aqxmldoc;
  }
}
