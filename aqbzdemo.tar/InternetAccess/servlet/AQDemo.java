/* $Header: AQxmlServlet.java 12-jun-00.17:20:42 bnainani Exp $ */

/* Copyright (c) Oracle Corporation 2000. All Rights Reserved. */

/*
   DESCRIPTION
    Sample AQ servlet

*/

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import oracle.AQ.*;
import oracle.AQ.xml.*;
import java.sql.*;
import java.io.*;
//import oracle.jdbc.pool.*;

/**
 * This is a sample AQ Servlet.  
 */
public class AQDemo extends oracle.AQ.xml.AQxmlServlet20
{ 


  //========================================================================
  /*
   *  getDBDrv - specify the database to which the servlet will connect
   */
  public AQxmlDataSource createAQDataSource() throws AQxmlException
  {
    AQxmlDataSource  db_drv = null;
    
    System.err.println("AQTestServlet - setting db driver");

    /* CHANGE THIS LINE 
     * Create database driver with username/password, sid, host, port */
    db_drv = new AQxmlDataSource("bz", "bz", "BGOYALDB", "bgoyal-sun",
			    "1521");

    return db_drv;
  }

    
  //========================================================================
  public void init(ServletConfig config)
  {
      AQxmlDataSource  db_drv = null;

      try
      {
	PrintStream debugFile = new PrintStream (new FileOutputStream("/tmp/aqdebuglog"));
	debugFile.println("Function Called");
	debugFile.flush();
	super.init(config);
        AQxmlDebug.setTraceLevel(5);
        AQxmlDebug.setDebug(true);
	AQxmlDebug.setLogStream(new FileOutputStream("/tmp/aqlogfile"));

        db_drv = createAQDataSource();

	setAQDataSource(db_drv);

	System.err.println("AQTestServlet - setting style sheet");

	/* CHANGE THIS LINE */
//	setStyleSheet("text/xsl", "bizCard.xsl");
      }
      catch (AQxmlException aq_ex)
      {
	System.out.println("AQ exception: " + aq_ex);
	aq_ex.printStackTrace();

	aq_ex.getNextException().printStackTrace();
      }
      catch (Exception ex)
      {
	System.out.println("Exception: " + ex);
	ex.printStackTrace();
      }
  }
      
}
 
