sqlplus system/manager << EOF
set echo on
@tdcts.sql 
@bz_ia_main.sql bz bz_adm demo temp manager
