REM script name: bz_ia_priv.sql
REM grants privileges to enqueue and dequeue to user bz
REM Creates Internet users Bob and Jane
REM Grants appropriate privileges to bz for internet_access
REM
REM version: 9.0.1
REM change:  initial version
REM


define bz_pass = &1
define master_pass = &2

CONNECT bz/&bz_pass

execute dbms_aqadm.drop_aq_agent(agent_name=>'bob');
execute dbms_aqadm.drop_aq_agent(agent_name=>'jane');

REM Allows access to the queues via the servlets
execute dbms_aqadm.create_aq_agent(agent_name=>'bob', enable_http =>true);
execute dbms_aqadm.create_aq_agent(agent_name=>'jane', enable_http =>true);
execute dbms_aqadm.enable_db_access('bob', 'BZ');
execute dbms_aqadm.enable_db_access('jane', 'BZ');


REM make sure that bz already has aq_user_role and excecute on dbms_aq

CONNECT system/&master_pass as sysdba;
alter user bz grant connect through bz;
