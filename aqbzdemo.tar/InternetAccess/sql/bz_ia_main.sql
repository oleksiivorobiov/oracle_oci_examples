REM script name: bz_ia_main.sql
REM It creates the internet users for AQ access and grants 
REM privileges to bz for internet access 
REM 
REM Assumes the generic set up for AQ BizCard Demo has been 
REM done
REM
REM version: 9.0.1
REM change:  initial version
REM
REM =======================================================
REM cleanup section
REM =======================================================

SET VERIFY OFF

define bz_pass      = &1
define master_pass  = &5

SPOOL bz_ia

@@bz_ia_priv.sql &bz_pass &master_pass

spool off
