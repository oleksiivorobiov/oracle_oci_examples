REM script name: bz_cre.sql
REM Creates queue tables, queues - bzcardorders_q
REM Starts the queue
REM
REM version: 9i
REM

REM =======================================================
REM cleanup section
REM =======================================================
BEGIN
  dbms_aqadm.stop_queue(queue_name => 'bzcardorders_q');
  dbms_aqadm.drop_queue (
        queue_name              => 'bzcardorders_q');
  dbms_aqadm.drop_queue_table (
        queue_table => 'bzcardorders_qt');
END;
/

REM =======================================================
REM Create queue tables, queues for BZADM
REM =======================================================

 execute dbms_aqadm.create_queue_table(		 -
        queue_table => 'bzcardorders_qt', -
        comment => 'Business Card Orders queue table',	-
	multiple_consumers => true, -
        queue_payload_type => 'bzcardorder_typ',-
	primary_instance => 1,-
        secondary_instance => 2);


REM =======================================================
REM Create a queue 
REM =======================================================
BEGIN
dbms_aqadm.create_queue (
        queue_name              => 'bzcardorders_q',
        queue_table             => 'bzcardorders_qt');
END;
/

REM =======================================================
REM start queue
REM =======================================================
BEGIN
  dbms_aqadm.start_queue (
        queue_name              => 'bzcardorders_q');
END;
/
