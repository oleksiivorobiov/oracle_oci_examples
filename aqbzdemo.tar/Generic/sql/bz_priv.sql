REM script name: bz_priv.sql
REM grants privileges to enqueue and dequeue to user bz
REM
REM version: 9.0.1
REM

REM ========================================================
REM Grant Enqueue and Dequeue privilege on bzcardorders_q to queue 
REM to bz user
REM ========================================================

grant execute on bzcardorder_typ to bz;

begin
dbms_aqadm.grant_queue_privilege(privilege => 'ALL', 
			 	queue_name => 'bzcardorders_q', 
				grantee => 'bz', 
				grant_option => TRUE);
end;
/
