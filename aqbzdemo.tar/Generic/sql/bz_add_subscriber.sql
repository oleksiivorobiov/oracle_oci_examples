REM script name: bz_add_subscriber.sql
REM This script adds a subscriber to bzcardorders_q
REM
REM version: 9i

REM =======================================================
REM cleanup section
REM =======================================================
execute dbms_aqadm.remove_subscriber ( -
	  queue_name => 'BZCARDORDERS_Q', -
	  subscriber => sys.aq$_agent('SHIPPING',null,null)-
);

execute dbms_aqadm.remove_subscriber ( -
	  queue_name => 'BZCARDORDERS_Q', -
	  subscriber => sys.aq$_agent('BILLING',null,null)-
);

execute dbms_aqadm.remove_subscriber ( -
	  queue_name => 'BZCARDORDERS_Q', -
	  subscriber => sys.aq$_agent('RUSH_ORDER',null,null)-
);
REM =======================================================
REM Add subscriber 'SHIPPING'and 'BILLING' to BZCARDORDERS_Q
REM =======================================================
execute dbms_aqadm.add_subscriber ( -
	  queue_name => 'BZCARDORDERS_Q', -
	  subscriber => sys.aq$_agent('SHIPPING',null,null)-
);

quit;

execute dbms_aqadm.add_subscriber ( -
	  queue_name => 'BZCARDORDERS_Q', -
	  subscriber => sys.aq$_agent('BILLING',null,null)-
);

REM =======================================================
REM Add a rule-based subscriber 'RUSH_ORDER' to BZCARDORDERS_Q
REM =======================================================
execute dbms_aqadm.add_subscriber ( -
	  queue_name => 'BZCARDORDERS_Q', -
	  subscriber => sys.aq$_agent('RUSH_ORDER',null,null), -
	  rule => 'tab.user_data.ord_typ = ''RUSH''' -
);
