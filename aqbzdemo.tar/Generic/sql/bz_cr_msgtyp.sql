REM script name: bz_cr_msgtyp.sql
REM creates the bzcardorder_typ Object type
REM
REM version: 9i

REM =======================================================
REM cleanup section
REM =======================================================

DROP TYPE bzcardorder_typ;

REM =======================================================
REM Creates the bzcardorder_type. Users using this type would
REM need execute privilege on this type
REM =======================================================

CREATE OR REPLACE TYPE bzcardorder_typ AS OBJECT (
	employee_id	NUMBER(6),
	first_name	VARCHAR2(20),
	last_name	VARCHAR2(25),
	ordtyp		VARCHAR(10));	
/
