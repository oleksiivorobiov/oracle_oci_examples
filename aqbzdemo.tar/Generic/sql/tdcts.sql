REM script name:     tdcts.sql
REM purpose:         Create tablespaces for setting up Common Schema
REM version:
REM modifications:
REM **************************************************************************

connect / as sysdba

REM
REM To drop tablespaces if they exist
REM

drop tablespace smundo including contents and datafiles;
drop tablespace demo including contents and datafiles;
drop tablespace temp including contents and datafiles;

REM
REM To create new tablespaces
REM

create undo tablespace smundo
       datafile 'smundo.dbf' size 5M
       autoextend on extent management local;

create tablespace demo
       datafile 'demo.dbf' size 10M
       autoextend on extent management local autoallocate;

create temporary tablespace temp
       tempfile 'temp.dbf' size 5M
       autoextend on;

