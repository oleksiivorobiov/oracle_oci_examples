REM script name: bz_xml_main.sql
REM Creates an xml-typed queue bzcardxmlo_q and an xml-tranformation
REM 
REM 
REM 
REM
REM version: 9.0.1
REM change:  initial version

define bz_adm = &1

REM =======================================================
REM cleanup section
REM =======================================================

SET VERIFY OFF

spool bz_xml

CONNECT bz_adm/&bz_adm
REM =======================================================
REM CREATE an object type with XMLType attribute
REM =======================================================

@@bz_xml_cr_msgtyp.sql

REM =======================================================
REM CREATE a queue with XMLType payload
REM =======================================================

@@bz_xml_cr_q.sql

REM =======================================================
REM CREATE a transformation from an object type to XMLType
REM =======================================================

@@bz_xml_mapping.sql

spool off
